package com.example.instant;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;


public class DBHelper extends SQLiteOpenHelper{
    public static final String dbname = "service.db";  // Declaring database name

    public DBHelper(Context context) {   // constructor of DBHelper
        super(context, dbname,null, 1);
    }

    @Override   // onCreate method
    public void onCreate(SQLiteDatabase MyDB) {
        MyDB.execSQL("Create Table users(email Text primary key,username Text, password Text)");

    }

    @Override  // onUpgrade
    public void onUpgrade(SQLiteDatabase MyDB, int i, int i1) {
        MyDB.execSQL("drop table if exists users");

    }
    // Register user in app
    public boolean insertData(String email, String username, String password){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("email", email);
        contentValues.put("username", username);
        contentValues.put("password", password);
        long result = MyDB.insert("users", null, contentValues);
        return result != -1;
    }
    // for checking existing user
    public boolean checkUser(String username){  //
        SQLiteDatabase MyDB = this.getWritableDatabase();
        try (Cursor cursor = MyDB.rawQuery("Select * from users where username = ?", new String[]{username})) {
            return cursor.getCount() > 0;
        }
    }
    // For login authentication
    public boolean checkusernamepassword(String username, String password){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        try (Cursor cursor = MyDB.rawQuery("Select * from users where username = ? and password = ?", new String[]{username, password})) {
            return cursor.getCount() > 0;
        }
    }

    // reading all data from database
    public Cursor readalldata() {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        String qry = "select * from work_details";
        return MyDB.rawQuery(qry, null);
    }

    // deleting all data from database
    public boolean deleteuser(String username){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        try (Cursor cr = MyDB.rawQuery("Select * from users where username = ?", new String[]{username})) {
            if (cr.getCount() > 0) {
                long result = MyDB.delete("users", "username = ?", new String[]{username});
                return result != -1;
            } else
                return false;
        }
    }


}
