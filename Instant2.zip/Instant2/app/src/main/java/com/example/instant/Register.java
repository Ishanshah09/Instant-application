package com.example.instant;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Register extends AppCompatActivity {
    EditText txtemail, txtuser, txtpass , txtrepass;
    Button btnRegister;
    DBHelper DB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        txtemail = (EditText) findViewById(R.id.txtRemail);
        txtuser = (EditText) findViewById(R.id.txtRuser);
        txtpass = (EditText) findViewById(R.id.txtRpass);
        txtrepass = (EditText) findViewById(R.id.txtrepass);
        btnRegister = (Button) findViewById(R.id.btnRegister);
        DB = new DBHelper(this);

        btnRegister.setOnClickListener(view -> {
            String email = txtemail.getText().toString();
            String user = txtuser.getText().toString();
            String pass = txtpass.getText().toString();
            String repass = txtpass.getText().toString();
            if (email.isEmpty() || user.isEmpty() || pass.isEmpty() || repass.isEmpty()){
                Toast.makeText(Register.this, "Enter all fields", Toast.LENGTH_LONG).show();
            }
            else{
                if (pass.equals(repass)){
                    boolean checkUser = DB.checkUser(user);
                    if (!checkUser){
                        boolean insert = DB.insertData(email, user, pass);
                        if (insert){
                            Toast.makeText(this, "Registered Successfully", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(Register.this, MainActivity.class);
                            startActivity(intent);
                        }
                        else {
                            Toast.makeText(this, "Registration failed", Toast.LENGTH_SHORT).show();
                        }
                    }
                    else{
                        Toast.makeText(this, "User already exists", Toast.LENGTH_SHORT).show();
                    }
                }
                else{
                    Toast.makeText(this, "Password not matched", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}