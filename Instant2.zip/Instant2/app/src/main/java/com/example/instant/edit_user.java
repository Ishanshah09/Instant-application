package com.example.instant;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class edit_user extends AppCompatActivity {
    EditText txtname, txtmail, txtphone, txtaddress;
    Button btnedit;
    DBHelper1 DB1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_user);

        txtname = findViewById(R.id.txtUname);
        txtmail = findViewById(R.id.txtUmail);
        txtphone = findViewById(R.id.txtUphone);
        txtaddress = findViewById(R.id.txtUaddress);
        btnedit = findViewById(R.id.btnedit);
        DB1 = new DBHelper1(this);

        // update user details
        btnedit.setOnClickListener(v -> {
            String name = txtname.getText().toString();
            String mail = txtmail.getText().toString();
            String phone = txtphone.getText().toString();
            String address = txtaddress.getText().toString();

            boolean i=DB1.update_data(mail, name, phone, address);
            if(i)
            {
                Toast.makeText(edit_user.this, "Record Updated", Toast.LENGTH_SHORT).show();
            }
            else
            {
                Toast.makeText(edit_user.this,"Record Updating Failed", Toast.LENGTH_SHORT).show();
            }
            txtname.setText("");
            txtmail.setText("");
            txtphone.setText("");
            txtaddress.setText("");
        });
    }
}