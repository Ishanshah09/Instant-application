package com.example.instant;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Search extends AppCompatActivity {
    TextView home, search, account, phone;
    // creating variables for our array list,
    // DBHelper3, adapter and recycler view.
    private ArrayList<model> courseModalArrayList;
    private DBHelper3 dbHandler;
    private CustomAdapter courseRVAdapter;
    private RecyclerView coursesRV;
    private SearchView searchView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        home = findViewById(R.id.navHome);
        search = findViewById(R.id.navSearch);
        account = findViewById(R.id.navAccount);

        phone = findViewById(R.id.idTVCourseDescription);
        searchView = findViewById(R.id.searchView);     // Search view
        searchView.clearFocus();

//        phone.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                String call = idTVCourseDescription.getText().toString();
//                Intent intent = new Intent(Intent.ACTION_CALL);
//                intent.setData(Uri.parse(""));
//            }
//        });
        // initializing our all variables.
        courseModalArrayList = new ArrayList<>();
        dbHandler = new DBHelper3(Search.this);

        // getting our course array
        // list from db handler class.
        courseModalArrayList = dbHandler.readCourses();

        // on below line passing our array lost to our adapter class.
        courseRVAdapter = new CustomAdapter(courseModalArrayList, Search.this);
        coursesRV = findViewById(R.id.idRVCourses);

        // setting layout manager for our recycler view.
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(Search.this, RecyclerView.VERTICAL, false);
        coursesRV.setLayoutManager(linearLayoutManager);

        // setting our adapter to recycler view.
        coursesRV.setAdapter(courseRVAdapter);

        // _____For navigating between Home, Search, Account_____
        home.setOnClickListener(v -> {
            Intent intent = new Intent(Search.this, Home.class);    // Home page
            startActivity(intent);

        });
        search.setOnClickListener(v -> {
            Toast.makeText(this, "You are on Search page", Toast.LENGTH_SHORT).show();  // search page

        });
        account.setOnClickListener(v -> {
            Intent intent = new Intent(Search.this, Account.class);  // Account page
            startActivity(intent);

        });

        // search view
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                fileList(newText);
                return true;
            }
        });

    }

    private void fileList(String text) {
        ArrayList<model> filteredList = new ArrayList<>();
        for (model item : courseModalArrayList){
            if (item.getName().toLowerCase().contains(text.toLowerCase())){
                filteredList.add(item);
            }
        }
        if (filteredList.isEmpty()){
            Toast.makeText(this, "No data found", Toast.LENGTH_SHORT).show();
        }
        else{
//            CustomAdapter.setFilteredList(filteredList);
        }
    }
}




