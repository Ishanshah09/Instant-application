package com.example.instant;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class Account extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        TextView home, search, account, user_name;
        Button btnLogout, btndelete, btnedit;
        CardView about;
        DBHelper DB;

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_account);
        home = findViewById(R.id.navHome);
        search = findViewById(R.id.navSearch);
        account = findViewById(R.id.navAccount);
        user_name = findViewById(R.id.usernameDis);
        btnLogout = findViewById(R.id.btnlogout);
        about = findViewById(R.id.about_us);
        btndelete = findViewById(R.id.btndelete);
        btnedit = findViewById(R.id.btndedit);

        DB = new DBHelper(this);

        // receiving username from login activity
        SharedPreferences sharedPreferences = getSharedPreferences("myKey", MODE_PRIVATE);
        String value = sharedPreferences.getString("value","");
        user_name.setText(value);

        // display about us
        about.setOnClickListener(v -> {
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
            alertDialogBuilder.setTitle("About Us");
            alertDialogBuilder.setMessage("Name: Ishan.D.shah \n Std: TYBCA(sem-5) \n Roll no: 45 \nCollege: Narmada college of Science and Commerce");
            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show();
        });

        // delete user details on click of delete button
        btndelete.setOnClickListener(v -> {
            String value1 = sharedPreferences.getString("value","");
            boolean i = DB.deleteuser(value1);
            if (i){
                Toast.makeText(this, "Record deleted", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Account.this, MainActivity.class);
                startActivity(intent);
            }
            else{
                Toast.makeText(this, "Deletion failed", Toast.LENGTH_SHORT).show();
            }
        });

        // Edit button for editing User details
        btnedit.setOnClickListener(v -> {
            Intent intent = new Intent(Account.this, edit_user.class);
            startActivity(intent);
        });

        // Logout button (User will redirect to login page)
        btnLogout.setOnClickListener(v -> {
            Intent intent = new Intent(Account.this, MainActivity.class);
            startActivity(intent);
            onBackPressed();
        });

        // _____For navigating between Home, Search, Account_____
        home.setOnClickListener(v -> {
            Intent intent = new Intent(Account.this, Home.class);    // Home page
            startActivity(intent);

        });
        search.setOnClickListener(v -> {
            Intent intent = new Intent(Account.this, Search.class);  // search page
            startActivity(intent);

        });
        account.setOnClickListener(v -> {
            Toast.makeText(this, "You are on Account page", Toast.LENGTH_SHORT).show();  // Account page

        });


    }
}