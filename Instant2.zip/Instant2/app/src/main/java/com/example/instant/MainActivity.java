package com.example.instant;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {
    EditText txtuser, txtpass;
    TextView txtreg;
    Button btnLogin;
    DBHelper DB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtuser = findViewById(R.id.txtuser);
        txtpass = findViewById(R.id.txtpass);
        btnLogin = findViewById(R.id.button2);
        txtreg = findViewById(R.id.txtreg);
        DB = new DBHelper(this);

        btnLogin.setOnClickListener(view -> {
            String userVal = txtuser.getText().toString();
            String passVal = txtpass.getText().toString();
            if (userVal.isEmpty() || passVal.isEmpty()){
                Toast.makeText(MainActivity.this, "Enter all Values",Toast.LENGTH_SHORT).show();
            }
            else{
                boolean checkuserpass = DB.checkusernamepassword(userVal, passVal);
                if(checkuserpass){
                    Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(MainActivity.this, Home.class);
                    startActivity(intent);
                    finish();

                    // Sending username from login page to account page
                    SharedPreferences sharedPref = getSharedPreferences("myKey", MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPref.edit();
                    editor.putString("value", userVal);
                    editor.apply();

                }
                else{
                    Toast.makeText(this, "Invalid details", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Redirect to registration page
        txtreg.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, Register.class);
            startActivity(intent);
        });


    }
}