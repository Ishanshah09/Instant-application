package com.example.instant;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;


public class DBHelper3 extends SQLiteOpenHelper {
    public static final String dbname = "service2.db";  // Declaring database name
    public static final String tbname = "workerDetails";  // Declaring database name

    public DBHelper3(Context context) {
        super(context, dbname, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("Create table workerdetails(id INTEGER, name TEXT primary key, phone TEXT, address TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("Drop table if exists workerdetails");
        onCreate(db);
    }

    // optional
    public boolean insertdata(Integer id, String name, String phone, String address){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("id", id);
        cv.put("name", name);
        cv.put("phone", phone);
        cv.put("address", address);
        long result = db.insert("workerdetails",null,cv);
        return result != -1;
    }

    //view data code
    public Cursor getinfo(){    // Display details who has ID = 1
        SQLiteDatabase db=this .getWritableDatabase();
        return db.rawQuery("select * from workerdetails where id = 1",null);
    }
    public Cursor getinfo1(){    // Display details who has ID = 2
        SQLiteDatabase db=this .getWritableDatabase();
        return db.rawQuery("select * from workerdetails where id = 2",null);
    }
    public Cursor getinfo2(){    // Display details who has ID = 3
        SQLiteDatabase db=this .getWritableDatabase();
        return db.rawQuery("select * from workerdetails where id = 3",null);
    }
    public Cursor getinfo3(){    // Display details who has ID = 4
        SQLiteDatabase db=this .getWritableDatabase();
        return db.rawQuery("select * from workerdetails where id = 4",null);
    }
    public Cursor getinfo4(){    // Display details who has ID = 5
        SQLiteDatabase db=this .getWritableDatabase();
        return db.rawQuery("select * from workerdetails where id = 5",null);
    }

    //fetch data
    // we have created a new method for reading all the courses.
    public ArrayList<model> readCourses() {
        // on below line we are creating a
        // database for reading our database.
        SQLiteDatabase db = this.getReadableDatabase();

        // on below line we are creating a cursor with query to read data from database.
        Cursor cursorCourses = db.rawQuery("SELECT * FROM " + tbname, null);

        // on below line we are creating a new array list.
        ArrayList<model> courseModalArrayList = new ArrayList<>();

        // moving our cursor to first position.
        if (cursorCourses.moveToFirst()) {
            do {
                // on below line we are adding the data from cursor to our array list.
                courseModalArrayList.add(new model(cursorCourses.getString(1),
                        cursorCourses.getString(2),
                        cursorCourses.getString(3)));
            } while (cursorCourses.moveToNext());
            // moving our cursor to next.
        }
        // at last closing our cursor
        // and returning our array list.
        cursorCourses.close();
        return courseModalArrayList;
    }

}
