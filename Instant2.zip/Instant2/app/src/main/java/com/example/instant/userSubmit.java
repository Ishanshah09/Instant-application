package com.example.instant;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class userSubmit extends AppCompatActivity {
    EditText txtname, txtmail, txtphone,txtaddress;
    TextView txtback;
    Button btnSubmit;
    DBHelper1 DB1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_submit);
        txtname = findViewById(R.id.txtUname);
        txtmail = findViewById(R.id.txtUmail);
        txtphone = findViewById(R.id.txtUphone);
        txtaddress = findViewById(R.id.txtUaddress);
        btnSubmit = findViewById(R.id.btnSubmit);
        txtback = findViewById(R.id.back);
        DB1 = new DBHelper1(this);

        // Go back to home page
        txtback.setOnClickListener(v -> {
            Intent intent = new Intent(userSubmit.this, Home.class);
            startActivity(intent);
        });

        // Submit User details in database
        btnSubmit.setOnClickListener(v -> {
            String name = txtname.getText().toString();
            String mail = txtmail.getText().toString();
            String phone = txtphone.getText().toString();
            String address = txtaddress.getText().toString();

            if (name.isEmpty() || mail.isEmpty() || phone.isEmpty() || address.isEmpty()){
                Toast.makeText(this, "Enter all details", Toast.LENGTH_SHORT).show();
            }
            else{
                boolean insert = DB1.insertData_user(name, mail, phone, address);
                if (insert){
                    Toast.makeText(this, "Details Submitted", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(this, "Details Submission failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
        txtname.setText("");
        txtmail.setText("");
        txtphone.setText("");
        txtaddress.setText("");
        }
    }