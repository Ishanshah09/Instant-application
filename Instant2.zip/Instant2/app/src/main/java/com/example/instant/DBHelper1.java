package com.example.instant;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper1 extends SQLiteOpenHelper {
    public static final String dbname = "service1.db";  // Declaring database name
    public DBHelper1(Context context) {
        super(context, dbname, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String qry = "Create table userDetails (name TEXT, mail TEXT PRIMARY KEY, phone TEXT UNIQUE,address TEXT)";
        db.execSQL(qry);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists userDetails");
        onCreate(db);
    }

    // ___ Details from user_details table ___
    // Adding user details in app
    public boolean insertData_user(String name, String mail, String phone, String address) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name", name);
        cv.put("mail", mail);
        cv.put("phone", phone);
        cv.put("address", address);
        long result = db.insert("userDetails",null,cv);
        return result != -1;
    }

    // Update user
    public boolean update_data(String mail,String name, String phone, String address)
    {
        SQLiteDatabase db= this .getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("name",name);
        cv.put("phone",phone);
        cv.put("address", address);
        try (Cursor cr = db.rawQuery("select * from userDetails where mail=?", new String[]{mail})) {
            if (cr.getCount() > 0) {
                long r = db.update("userDetails", cv, "mail=?", new String[]{mail});
                return r != -1;
            } else
                return false;
        }
    }

}
