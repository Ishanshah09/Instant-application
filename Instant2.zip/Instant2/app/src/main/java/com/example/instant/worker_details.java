package com.example.instant;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class worker_details extends AppCompatActivity {
    EditText txtname;
    EditText txtphone;
    EditText txtaddress, txtiid;
    Button btnSubmit;
    DBHelper3 DB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_worker_details);

        txtname = findViewById(R.id.Wtxtname);
        txtphone = findViewById(R.id.Wtxtphone);
        txtaddress = findViewById(R.id.Wtxtadd);
        txtiid = findViewById(R.id.Wtxtid);
        btnSubmit = findViewById(R.id.Wbutton);
        DB = new DBHelper3(this);

        btnSubmit.setOnClickListener(v -> {
            String name = txtname.getText().toString();
            String phone = txtphone.getText().toString();
            String address = txtaddress.getText().toString();
            Integer id = Integer.valueOf(txtiid.getText().toString());
            if (name.isEmpty() || phone.isEmpty() || address.isEmpty()){
                Toast.makeText(worker_details.this, "Empty", Toast.LENGTH_SHORT).show();
            }
            else{
                boolean insert = DB.insertdata(id, name, phone, address);
                if(insert){
                    Toast.makeText(worker_details.this, "Success", Toast.LENGTH_SHORT).show();
                }
            }
        });


    }
}