package com.example.instant;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class Home extends AppCompatActivity {
    TextView home, search, account;
    Button btnclk;  // for insertion of worker
    ImageButton add;
    CardView app, carWash, ele, garden, comp, ldry, pest, tv, clean;
    DBHelper3 DB3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        home = findViewById(R.id.navHome);
        search = findViewById(R.id.navSearch);
        account = findViewById(R.id.navAccount);

        // initialize  Card Views
        app = findViewById(R.id.appCard);
        carWash = findViewById(R.id.carCard);
        ele = findViewById(R.id.eleCard);
        garden = findViewById(R.id.gardCard);
        comp = findViewById(R.id.comCard);
        ldry = findViewById(R.id.launCard);
        pest = findViewById(R.id.pestCard);
        tv = findViewById(R.id.tvCard);
        clean = findViewById(R.id.cleanCard);
        add = findViewById(R.id.add);

//        btnclk = findViewById(R.id.buttonInsert);
        DB3 = new DBHelper3(this);
        // For insert details of user
//        btnclk.setOnClickListener(v -> {
//            Intent intent = new Intent(Home.this, worker_details.class);
//            startActivity(intent);
//        });

        // redirect to home page
        home.setOnClickListener(v -> {
            Toast.makeText(this, "You are on Home page", Toast.LENGTH_SHORT).show();

        });

        // redirect to search page
        search.setOnClickListener(v -> {
            Intent intent = new Intent(Home.this, Search.class);
            startActivity(intent);

        });
        // redirect to account page
        account.setOnClickListener(v -> {
            Intent intent = new Intent(Home.this, Account.class);
            startActivity(intent);

        });
        // redirect to user-details for service
        add.setOnClickListener(v -> {
            Intent intent = new Intent(Home.this, userSubmit.class);
            startActivity(intent);
        });

        // view details "Appliances"
        app.setOnClickListener(v -> {

                Cursor c = DB3.getinfo();
                if (c.getCount() == 0) {
                    Toast.makeText(Home.this, "No data found", Toast.LENGTH_SHORT).show();
                }
                StringBuffer buffer = new StringBuffer();
                while (c.moveToNext()) {
                    buffer.append("Name: " + c.getString(1) + "\n");
                    buffer.append("Phone no :" + c.getString(2) + "\n");
                    buffer.append("Address: " + c.getString(3) + "\n\n\n");
                }
                AlertDialog.Builder builder = new AlertDialog.Builder(Home.this);
                builder.setCancelable(true);
                builder.setTitle("Worker Details");
                builder.setMessage(buffer.toString());
                builder.show();

        });
        // For display details of car wash
        carWash.setOnClickListener(v -> {
            Cursor c = DB3.getinfo1();
            if(c.getCount()==0)
            {
                Toast.makeText(Home.this, "No data found", Toast.LENGTH_SHORT).show();
            }
            StringBuffer buffer=new StringBuffer();
            while(c.moveToNext())
            {
                buffer.append("Name: "+c.getString(1)+"\n");
                buffer.append("Phone no :"+c.getString(2)+"\n");
                buffer.append("Address: "+c.getString(3)+"\n\n\n");
            }
            AlertDialog.Builder builder=new AlertDialog.Builder(Home.this);
            builder.setCancelable(true);
            builder.setTitle("Worker Details");
            builder.setMessage(buffer.toString());
            builder.show();
        });

        // For display details for electrician
        ele.setOnClickListener(v -> {
            Cursor c = DB3.getinfo2();
            if(c.getCount()==0)
            {
                Toast.makeText(Home.this, "No data found", Toast.LENGTH_SHORT).show();
            }
            StringBuffer buffer=new StringBuffer();
            while(c.moveToNext())
            {
                buffer.append("Name: "+c.getString(1)+"\n");
                buffer.append("Phone no :"+c.getString(2)+"\n");
                buffer.append("Address: "+c.getString(3)+"\n\n\n");
            }
            AlertDialog.Builder builder=new AlertDialog.Builder(Home.this);
            builder.setCancelable(true);
            builder.setTitle("Worker Details");
            builder.setMessage(buffer.toString());
            builder.show();
        });

        // For Display Gardner
        garden.setOnClickListener(v -> {
            Cursor c = DB3.getinfo3();
            if(c.getCount()==0)
            {
                Toast.makeText(Home.this, "No data found", Toast.LENGTH_SHORT).show();
            }
            StringBuffer buffer=new StringBuffer();
            while(c.moveToNext())
            {
                buffer.append("Name: "+c.getString(1)+"\n");
                buffer.append("Phone no :"+c.getString(2)+"\n");
                buffer.append("Address: "+c.getString(3)+"\n\n\n");
            }
            AlertDialog.Builder builder=new AlertDialog.Builder(Home.this);
            builder.setCancelable(true);
            builder.setTitle("Worker Details");
            builder.setMessage(buffer.toString());
            builder.show();
        });

        // For Display Computer
        comp.setOnClickListener(v -> {
            Cursor c = DB3.getinfo4();
            if(c.getCount()==0)
            {
                Toast.makeText(Home.this, "No data found", Toast.LENGTH_SHORT).show();
            }
            StringBuffer buffer=new StringBuffer();
            while(c.moveToNext())
            {
                buffer.append("Name: "+c.getString(1)+"\n");
                buffer.append("Phone no :"+c.getString(2)+"\n");
                buffer.append("Address: "+c.getString(3)+"\n\n\n");
            }
            AlertDialog.Builder builder=new AlertDialog.Builder(Home.this);
            builder.setCancelable(true);
            builder.setTitle("Worker Details");
            builder.setMessage(buffer.toString());
            builder.show();
        });

        // For display laundry
        ldry.setOnClickListener(v -> {
            Cursor c = DB3.getinfo4();
            if(c.getCount()==0)
            {
                Toast.makeText(Home.this, "No data found", Toast.LENGTH_SHORT).show();
            }
            StringBuffer buffer=new StringBuffer();
            while(c.moveToNext())
            {
                buffer.append("Name: "+c.getString(1)+"\n");
                buffer.append("Phone no :"+c.getString(2)+"\n");
                buffer.append("Address: "+c.getString(3)+"\n\n\n");
            }
            AlertDialog.Builder builder=new AlertDialog.Builder(Home.this);
            builder.setCancelable(true);
            builder.setTitle("Worker Details");
            builder.setMessage(buffer.toString());
            builder.show();
        });

        // For pest control
        pest.setOnClickListener(v -> {
            Cursor c = DB3.getinfo();
            if(c.getCount()==0)
            {
                Toast.makeText(Home.this, "No data found", Toast.LENGTH_SHORT).show();
            }
            StringBuffer buffer=new StringBuffer();
            while(c.moveToNext())
            {
                buffer.append("Name: "+c.getString(1)+"\n");
                buffer.append("Phone no :"+c.getString(2)+"\n");
                buffer.append("Address: "+c.getString(3)+"\n\n\n");
            }
            AlertDialog.Builder builder=new AlertDialog.Builder(Home.this);
            builder.setCancelable(true);
            builder.setTitle("Worker Details");
            builder.setMessage(buffer.toString());
            builder.show();
        });

        // For display TV
        tv.setOnClickListener(v -> {
            Cursor c = DB3.getinfo1();
            if(c.getCount()==0)
            {
                Toast.makeText(Home.this, "No data found", Toast.LENGTH_SHORT).show();
            }
            StringBuffer buffer=new StringBuffer();
            while(c.moveToNext())
            {
                buffer.append("Name: "+c.getString(1)+"\n");
                buffer.append("Phone no :"+c.getString(2)+"\n");
                buffer.append("Address: "+c.getString(3)+"\n\n\n");
            }
            AlertDialog.Builder builder=new AlertDialog.Builder(Home.this);
            builder.setCancelable(true);
            builder.setTitle("Worker Details");
            builder.setMessage(buffer.toString());
            builder.show();
        });

        // For Displaying Cleaning
        clean.setOnClickListener(v -> {
            Cursor c = DB3.getinfo2();
            if(c.getCount()==0)
            {
                Toast.makeText(Home.this, "No data found", Toast.LENGTH_SHORT).show();
            }
            StringBuffer buffer=new StringBuffer();
            while(c.moveToNext())
            {
                buffer.append("Name: "+c.getString(1)+"\n");
                buffer.append("Phone no :"+c.getString(2)+"\n");
                buffer.append("Address: "+c.getString(3)+"\n\n\n");
            }
            AlertDialog.Builder builder=new AlertDialog.Builder(Home.this);
            builder.setCancelable(true);
            builder.setTitle("Worker Details");
            builder.setMessage(buffer.toString());
            builder.show();
        });
    }
}