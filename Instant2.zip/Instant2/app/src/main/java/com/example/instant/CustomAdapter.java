package com.example.instant;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.ViewHolder> {

    // variable for our array list and context
    private ArrayList<model> courseModalArrayList;
    private final Context context;

    // constructor
    public CustomAdapter(ArrayList<model> courseModalArrayList, Context context) {
        this.courseModalArrayList = courseModalArrayList;
        this.context = context;
    }

    // this is for filter data
    @SuppressLint("NotifyDataSetChanged")
    public void setFilteredList(List<model> filteredList){
        this.courseModalArrayList = (ArrayList<model>) filteredList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // on below line we are inflating our layout
        // file for our recycler view items.
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.my_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // on below line we are setting data
        // to our views of recycler view item.
        model modal = courseModalArrayList.get(position);
        holder.courseNameTV.setText(modal.getName());
        holder.courseDescTV.setText(modal.getPhone());
        holder.courseTracksTV.setText(modal.getAddress());
    }

    @Override
    public int getItemCount() {
        // returning the size of our array list
        return courseModalArrayList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        // creating variables for our text views.
        private final TextView courseNameTV;
        private final TextView courseDescTV;
        private final TextView courseTracksTV;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            // initializing our text views
            courseNameTV = itemView.findViewById(R.id.idTVCourseName);
            courseDescTV = itemView.findViewById(R.id.idTVCourseDescription);
            courseTracksTV = itemView.findViewById(R.id.idTVCourseTracks);
        }
    }
}
